# fastMRI banding removal

This folder contains minimal code to train an orientation adversary model, as described in the paper [MRI Banding Removal via Adversarial Training](https://arxiv.org/abs/2001.08699).